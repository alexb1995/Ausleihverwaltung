<?php
echo $_GET['id'];
echo $_GET['resourceid'];

?>
